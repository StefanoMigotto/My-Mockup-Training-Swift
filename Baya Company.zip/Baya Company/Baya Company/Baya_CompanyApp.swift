//
//  Baya_CompanyApp.swift
//  Baya Company
//
//  Created by Stefano Migotto on 22/02/23.
//

import SwiftUI

@main
struct Baya_CompanyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
