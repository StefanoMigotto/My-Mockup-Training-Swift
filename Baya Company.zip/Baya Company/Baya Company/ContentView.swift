//
//  ContentView.swift
//  Baya Company
//
//  Created by Stefano Migotto on 22/02/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack{
            Circle()
                .offset(x: /*@START_MENU_TOKEN@*/-100.0/*@END_MENU_TOKEN@*/, y: /*@START_MENU_TOKEN@*/-300.0/*@END_MENU_TOKEN@*/)
                .foregroundColor(.green)
            VStack(alignment: .center){
                
                HStack{
                    Text("the baya company")
                        .font(.title2)
                        .fontWeight(.light)
                        .foregroundColor(.white)
                    Spacer()
                    Image(systemName: "bell.badge.circle.fill")
                        .resizable(capInsets: EdgeInsets(top: 0.0, leading: 0.0, bottom: 0.0, trailing: 0.0))
                        .frame(width: 40.0, height: 40.0)
                        
                }.scenePadding(/*@START_MENU_TOKEN@*/.minimum/*@END_MENU_TOKEN@*/, edges: [/*@START_MENU_TOKEN@*/.leading/*@END_MENU_TOKEN@*/, .trailing])
                
                HStack{
                    ZStack{
                        RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Corner Radius@*/10.0/*@END_MENU_TOKEN@*/)
                            .foregroundColor(.white)
                            .frame(width: 150, height: 160)
                            .padding()
                            .shadow(radius: 10)
                        VStack{
                            Image(systemName: "calendar.day.timeline.left")
                                .resizable(capInsets: EdgeInsets(top: 0.0, leading: 0.0, bottom: 0.0, trailing: 0.0))
                                .frame(width: 30.0, height: 30.0)
                            Text("Timeline")
                                .font(.title3)
                                .fontWeight(.bold)
                            Text("THE BAYA VICTORIA")
                                .font(.caption)
                                .fontWeight(.light)
                                .foregroundColor(/*@START_MENU_TOKEN@*/Color(hue: 1.0, saturation: 0.034, brightness: 0.655)/*@END_MENU_TOKEN@*/)
                            ProgressView(value: /*@START_MENU_TOKEN@*/0.5/*@END_MENU_TOKEN@*/)
                                .frame(width: 120.0)
                                .cornerRadius(/*@START_MENU_TOKEN@*/5.0/*@END_MENU_TOKEN@*/)
                                .foregroundColor(/*@START_MENU_TOKEN@*/.green/*@END_MENU_TOKEN@*/)
                                .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(hue: 0.307, saturation: 0.243, brightness: 0.983)/*@END_MENU_TOKEN@*/)
                                .offset(x:0,y:5)
                            Text("64% Completed")
                                .font(.caption2)
                                .fontWeight(.bold)
                                .foregroundColor(Color(hue: 0.295, saturation: 0.823, brightness: 0.742))
                                .offset(x:0,y:10)
                        }
                        .accentColor(/*@START_MENU_TOKEN@*/.green/*@END_MENU_TOKEN@*/)
                    }
                    ZStack{
                        RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Corner Radius@*/10.0/*@END_MENU_TOKEN@*/)
                            .foregroundColor(.white)
                            .frame(width: 150, height: 160)
                            .padding()
                            .shadow(radius: 10)
                        VStack{
                            Image(systemName: "globe.americas.fill")
                                .resizable(capInsets: EdgeInsets(top: 0.0, leading: 0.0, bottom: 0.0, trailing: 0.0))
                                .frame(width: 30.0, height: 30.0)
                            Text("Projects")
                                .font(.title3)
                                .fontWeight(.bold)
                            Text("5 PROJECTS")
                                .font(.caption)
                                .fontWeight(.light)
                                .foregroundColor(/*@START_MENU_TOKEN@*/Color(hue: 1.0, saturation: 0.034, brightness: 0.655)/*@END_MENU_TOKEN@*/)
                        }
                        .accentColor(/*@START_MENU_TOKEN@*/.green/*@END_MENU_TOKEN@*/)
                        .offset(x:0,y:-15)
                    }
                }
                HStack{
                    ZStack{
                        RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Corner Radius@*/10.0/*@END_MENU_TOKEN@*/)
                            .foregroundColor(.white)
                            .frame(width: 150, height: 160)
                            .padding()
                            .shadow(radius: 10)
                        VStack{
                            Image(systemName: "globe.americas.fill")
                                .resizable(capInsets: EdgeInsets(top: 0.0, leading: 0.0, bottom: 0.0, trailing: 0.0))
                                .frame(width: 30.0, height: 30.0)
                            Text("Projects")
                                .font(.title3)
                                .fontWeight(.bold)
                            Text("5 PROJECTS")
                                .font(.caption)
                                .fontWeight(.light)
                                .foregroundColor(/*@START_MENU_TOKEN@*/Color(hue: 1.0, saturation: 0.034, brightness: 0.655)/*@END_MENU_TOKEN@*/)
                        }
                        .accentColor(/*@START_MENU_TOKEN@*/.green/*@END_MENU_TOKEN@*/)
                        .offset(x:0,y:-15)
                    }
                    ZStack{
                        RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Corner Radius@*/10.0/*@END_MENU_TOKEN@*/)
                            .foregroundColor(.white)
                            .frame(width: 150, height: 160)
                            .padding()
                            .shadow(radius: 10)
                        VStack{
                            Image(systemName: "globe.americas.fill")
                                .resizable(capInsets: EdgeInsets(top: 0.0, leading: 0.0, bottom: 0.0, trailing: 0.0))
                                .frame(width: 30.0, height: 30.0)
                            Text("Projects")
                                .font(.title3)
                                .fontWeight(.bold)
                            Text("5 PROJECTS")
                                .font(.caption)
                                .fontWeight(.light)
                                .foregroundColor(/*@START_MENU_TOKEN@*/Color(hue: 1.0, saturation: 0.034, brightness: 0.655)/*@END_MENU_TOKEN@*/)
                        }
                        .accentColor(/*@START_MENU_TOKEN@*/.green/*@END_MENU_TOKEN@*/)
                        .offset(x:0,y:-15)
                    }
                }
                
                HStack{
                    
                    ZStack{
                        RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Corner Radius@*/10.0/*@END_MENU_TOKEN@*/)
                            .foregroundColor(.white)
                            .frame(width: 150, height: 160)
                            .padding()
                            .shadow(radius: 10)
                        VStack{
                            Image(systemName: "globe.americas.fill")
                                .resizable(capInsets: EdgeInsets(top: 0.0, leading: 0.0, bottom: 0.0, trailing: 0.0))
                                .frame(width: 30.0, height: 30.0)
                            Text("Projects")
                                .font(.title3)
                                .fontWeight(.bold)
                            Text("5 PROJECTS")
                                .font(.caption)
                                .fontWeight(.light)
                                .foregroundColor(/*@START_MENU_TOKEN@*/Color(hue: 1.0, saturation: 0.034, brightness: 0.655)/*@END_MENU_TOKEN@*/)
                        }
                        .accentColor(/*@START_MENU_TOKEN@*/.green/*@END_MENU_TOKEN@*/)
                        .offset(x:0,y:-15)
                    }.offset(x:11,y:0)
                    
                    Spacer()
                    
                }
                Spacer()
                    
            }
        }
        .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(red: 0.948, green: 0.973, blue: 0.99)/*@END_MENU_TOKEN@*/)
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
